var bootState = {

	create: function(){
	game.state.start('load');
	}

};